<?php
$username = $_POST['username'];
$password = $_POST['password'];

if ($username == "admin" && $password == "admin") {
    echo "<h2 style='color:black;'>Login berhasil!</h2>";
    echo "<h2>Selamat datang, <span style='color:blue; font-size: 50px;'>admin</span>.</h2>";
    echo "<h2><a href='soal2.php' style='color:purple;'>kembali ke halaman login</a></h2>";
} else {
    echo "<h2><p><span style='color:red;'>Username : $username Tidak Terdaftar!</span></p></h2>";
    echo "<h2><a href='soal2.php' style='color:purple;'>kembali ke halaman login</a></h2>";
}
?>