<!--Praktikum 12-->
<!--2373002 - Leony Cornelia-->

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Soal 1 2373002 Leony Cornelia</title>
    <style>
        table {
            border-collapse: collapse;
        }
        td {
            padding: 3px;
            width: 200px;
        }
    </style>
</head>

<body>
    <form action="soal1profilephp.php" method="post">
        <table border="1">
            <tr>
                <th align="center" colspan="2" bgcolor="lightgray"><h2>Add Profile</h2></th>
            </tr>
            <tr>
                <td>Name</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <td>Position</td>
                <td>
                    <select name="position">
                        <optgroup label="Programmer">
                            <option>Senior Programmer</option>
                            <option>Junior Programmer</option>
                        </optgroup>
                        <optgroup label="System Analyst">
                            <option>Senior Analyst</option>
                            <option>Junior Analyst</option>
                        </optgroup>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr>
                <td>Confirm Password</td>
                <td><input type="password" name="confirm"></td>
            </tr>
            <tr>
                <td colspan="2" align="right">
                    <input type="reset" value="Reset">
                    <input type="submit" value="Save">
                </td>
            </tr>
        </table>
    </form>
</body>
</html>