<?php
$name = $_POST['name'] ?? '';
$position = $_POST['position'] ?? '';
$password = $_POST['password'] ?? '';
$confirm = $_POST['confirm'] ?? '';

$errors = [];

if (empty($name)) {
    $errors[] = "<span style='color:red;'>Input Nama belum di isi!</span>";
}
if (empty($password)) {
    $errors[] = "<span style='color:red;'>Input Password belum di isi!</span>";
}
if (empty($confirm)) {
    $errors[] = "<span style='color:red;'>Input Confirm Password belum di isi!</span>";
}
if (!empty($password) && !empty($confirm) && $password !== $confirm) {
    $errors[] = "<span style='color:red;'>Password dan Confirm Password belum sama!</span>";
}

if (!empty($errors)) {
    foreach ($errors as $error) {
        echo "$error<br>";
    }
    echo "<br><a href='soal1.php'>kembali ke halaman add profile</a>";
} else {
    echo "
    <table>
        <tr>
            <th colspan='2'>Data yang Anda Masukkan!</th>
        </tr>
        <tr>
            <td>Name</td>
            <td>: $name</td>
        </tr>
        <tr>
            <td>Position</td>
            <td>: $position</td>
        </tr>
    </table>
    <a href='soal1.php'>back</a>
    ";
}
?>