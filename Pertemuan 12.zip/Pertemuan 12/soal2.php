<!--Praktikum 12-->
<!--2373002 - Leony Cornelia-->

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Soal 2 2373002 Leony Cornelia</title>
    <style>
        body { 
            font-family: 'Times New Roman', Times, serif; 
        }
        .header {
            background-color: navy;
            color: white;
            width: 405px;
            font-size: 35px;
            text-align: center;
            padding: 10px;
        }
        .form-container {
            width: 415px;
            padding: 10px;
        }
        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        .form-group label {
            width: 100px;
        }
        .form-group input {
            flex: 1;
            height: 25px;
            padding: 3px;
        }
        input[type="submit"] {
            margin-top: 5px;
            display: flex;
        }
    </style>
</head>

<body>
    <div class="header">Login</div>
    <div class="form-container">
        <form method="post" action="soal2loginphp.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password">
            </div>
            <input type="submit" value="Login">
        </form>
        <div>
            <hr>
            @UKM2014<br>
            Leony Cornelia - 2373002
        </div>
    </div>
</body>
</html>